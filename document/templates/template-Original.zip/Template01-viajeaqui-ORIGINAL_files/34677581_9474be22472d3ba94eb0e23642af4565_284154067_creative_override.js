(function() {
  var creativeDefinition = {
    customScriptUrl: '',
    isDynamic: false,
    delayedImpression: false,
    standardEventIds: {
      DISPLAY_TIMER: '2',
      INTERACTION_TIMER: '3',
      INTERACTIVE_IMPRESSION: '4',
      FULL_SCREEN_VIDEO_PLAYS: '5',
      FULL_SCREEN_VIDEO_COMPLETES: '6',
      FULL_SCREEN_AVERAGE_VIEW_TIME: '7',
      MANUAL_CLOSE: '8',
      BACKUP_IMAGE_IMPRESSION: '9',
      EXPAND_TIMER: '10',
      VIDEO_PLAY: '11',
      VIDEO_VIEW_TIMER: '12',
      VIDEO_COMPLETE: '13',
      VIDEO_INTERACTION: '14',
      VIDEO_PAUSE: '15',
      VIDEO_MUTE: '16',
      VIDEO_REPLAY: '17',
      VIDEO_MIDPOINT: '18',
      FULL_SCREEN_VIDEO: '19',
      VIDEO_STOP: '20',
      VIDEO_FIRST_QUARTILE: '960584',
      VIDEO_THIRD_QUARTILE: '960585',
      VIDEO_UNMUTE: '149645',
      FULL_SCREEN: '286263',
      DYNAMIC_CREATIVE_IMPRESSION: '536393',
      HTML5_CREATIVE_IMPRESSION: '871060'
    },
    exitEvents: [
      {
        name: 'Auto Play: CTA',
        reportingId: '1980113',
        url: 'http://www.google.com/intx/pt-BR/work/apps/business/?utm_source\x3dgdn\x26utm_medium\x3dcpc\x26utm_campaign\x3dLATAM-SMB-2014-Apps-gmail-gdn-Display\x26utm_content\x3dgmailq3-inlinerectangle-2',
        targetWindow: '_blank',
        windowProperties: ''
      },
      {
        name: 'Auto Play: catch all',
        reportingId: '1980115',
        url: 'http://www.google.com/intx/pt-BR/work/apps/business/?utm_source\x3dgdn\x26utm_medium\x3dcpc\x26utm_campaign\x3dLATAM-SMB-2014-Apps-gmail-gdn-Display\x26utm_content\x3dgmailq3-inlinerectangle-2',
        targetWindow: '_blank',
        windowProperties: ''
      },
      {
        name: 'User Interactive: CTA',
        reportingId: '1980112',
        url: 'http://www.google.com/intx/pt-BR/work/apps/business/?utm_source\x3dgdn\x26utm_medium\x3dcpc\x26utm_campaign\x3dLATAM-SMB-2014-Apps-gmail-gdn-Display\x26utm_content\x3dgmailq3-inlinerectangle-2',
        targetWindow: '_blank',
        windowProperties: ''
      },
      {
        name: 'User Interactive: catch all',
        reportingId: '1980110',
        url: 'http://www.google.com/intx/pt-BR/work/apps/business/?utm_source\x3dgdn\x26utm_medium\x3dcpc\x26utm_campaign\x3dLATAM-SMB-2014-Apps-gmail-gdn-Display\x26utm_content\x3dgmailq3-inlinerectangle-2',
        targetWindow: '_blank',
        windowProperties: ''
      }
    ],
    timerEvents: [
    ],
    counterEvents: [
      {
        name: 'Auto Play: Replayed',
        reportingId: '1980111',
        videoData: null
      },
      {
        name: 'Input Field Selected: Business Name',
        reportingId: '1980114',
        videoData: null
      },
      {
        name: 'Input Field Selected: First Name',
        reportingId: '1980107',
        videoData: null
      },
      {
        name: 'User Info: Submitted',
        reportingId: '1980109',
        videoData: null
      },
      {
        name: 'User Interactive: Replayed',
        reportingId: '1980108',
        videoData: null
      }
    ],
    childFiles: [
      {
        name: 'pr_Google_Enterprise_Basic_300x250_Child_IA.swf',
        url: '/ads/richmedia/studio/pv2/32939292/20141028064348246/pr_Google_Enterprise_Basic_300x250_Child_IA.swf',
        isVideo: false,
        transcodeInformation: null
      },
      {
        name: 'pr_Google_Enterprise_Basic_300x250_IA.jpg',
        url: '/ads/richmedia/studio/pv2/32939292/20141028064348246/pr_Google_Enterprise_Basic_300x250_IA.jpg',
        isVideo: false,
        transcodeInformation: null
      }
    ],
    videoFiles: [
    ],
    videoEntries: [
    ],
    primaryAssets: [
      {
        id: '34632478',
        artworkType: 'FLASH',
        displayType: 'BANNER',
        width: '300',
        height: '250',
        servingPath: '/ads/richmedia/studio/pv2/32939292/20141028064348246/pr_Google_Enterprise_Basic_300x250_Shell_IA.swf',
        zIndex: '1000000',
        customCss: '',
        flashArtworkTypeData: {
          actionscriptVersion: '3',
          wmode: 'opaque',
          sdkVersion: '2.4.4',
          flashBackgroundColor: '',
          allowScriptAccess: 'always'
        },
        htmlArtworkTypeData: null,
        floatingDisplayTypeData: null,
        expandingDisplayTypeData: null,
        imageGalleryTypeData: null,
        pageSettings:null,
layoutsConfig: null,
layoutsApi: null
      }
    ]
  }
  var rendererDisplayType = '';
  rendererDisplayType += 'flash_';
  var rendererFormat = 'inpage';
  var rendererName = rendererDisplayType + rendererFormat;

  var creativeId = '59032019';
  var adId = '284154067';
  var templateVersion = '200_58';
  var studioObjects = window['studioV2'] = window['studioV2'] || {};
  var creativeObjects = studioObjects['creatives'] = studioObjects['creatives'] || {};
  var creativeKey = [creativeId, adId].join('_');
  var creative = creativeObjects[creativeKey] = creativeObjects[creativeKey] || {};
  creative['creativeDefinition'] = creativeDefinition;
  var adResponses = creative['adResponses'] || [];
  for (var i = 0; i < adResponses.length; i++) {
    adResponses[i].creativeDto && adResponses[i].creativeDto.csiEvents &&
        (adResponses[i].creativeDto.csiEvents['pe'] =
            adResponses[i].creativeDto.csiEvents['pe'] || (+new Date));
  }
  var loadedLibraries = studioObjects['loadedLibraries'] = studioObjects['loadedLibraries'] || {};
  var versionedLibrary = loadedLibraries[templateVersion] = loadedLibraries[templateVersion] || {};
  var typedLibrary = versionedLibrary[rendererName] = versionedLibrary[rendererName] || {};
  if (typedLibrary['bootstrap']) {
    typedLibrary.bootstrap();
  }
})();
