/* Abril ID:  version 1.01; date: 08-05-2011 */

var _abrIDMetrics = {
  uaCode : GOOGLE_ANALYTICS_UA,
  domain : ".abril.com.br",

  gaIsLoaded : function() {
	  return ((window._gat)? true : false );
  },
  init : function(func, path_category, action,label ) {
	  if (this.gaIsLoaded()) {
		 	try {
		 		var ID_tracker = _gat._createTracker(this.uaCode, "abrilid-widget");
		 		ID_tracker._setDomainName(this.domain);
		 		ID_tracker._setAllowLinker(true);
		 		if(func == "_trackPageview") {
		 			ID_tracker._trackPageview(path_category);

		 		} else {
                    if(AIW_BASE_URI == "http://local.id.abril.com.br:3000"){
                        console.log( "Categoria: " + path_category + " & Acao: " +  action + " & Label: " + label);
                        ID_tracker._trackEvent(path_category, action, label);
                    } else if(AIW_BASE_URI == "http://dev.id.abril.com.br" || AIW_BASE_URI == "http://qa.id.abril.com.br"){
                        console.log( "Categoria: " + path_category + " & Acao: " +  action + " & Label: " + label);
                        ID_tracker._trackEvent(path_category, action, label);
                    } else {
                        ID_tracker._trackEvent(path_category, action, label);
                    }

		 		}
			} catch(err) {};
		} else {
			//Page without G.A. script
			window._gaq = window._gaq || [];
	  		_gaq.push(['_setAccount', this.uaCode]);
	  		_gaq.push(['_setDomainName', this.domain]);
            _gaq.push(['_trackPageview', path_category ]);
            if(func == "_trackPageview") {
                _gaq.push(['_trackPageview', path_category]);
            } else {
            	_gaq.push(['_trackEvent', path_category, action, label]);
            }		

	  		(function() {
				var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
				ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  		})();
		 }

  },

  callHit : function(path) {
	this.init("_trackPageview",path);
  },

  eventHit : function(category,action,label) {
	this.init("_trackEvent", category, action, label);
  }
}
