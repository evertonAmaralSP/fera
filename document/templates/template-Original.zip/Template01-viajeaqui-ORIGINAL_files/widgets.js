document.writeln('<script type="text/javascript" src="http://id.abril.com.br/javascripts/abrilid-widgets-min-v9.js"></script>');
