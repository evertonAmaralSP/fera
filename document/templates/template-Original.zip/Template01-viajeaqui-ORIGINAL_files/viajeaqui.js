//definir posicoes
//variaveis para montar o iframe Vitrine Randomizer BuscaPé
var iframe_BP_G = '<iframe src="http://templates.buscape.com/dynatemplate/abril_home.html?type=home" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:940px; height:300px;" allowtransparency="true"></iframe>';
var iframe_BP_M = '<iframe width="940" height="180" scrolling="no" frameborder="0" src="http://templates.buscape.com/dynatemplate/abril_abasdecategorias.html?type=viajeaqui"></iframe>';
var iframe_BP_P = '<iframe width="300" height="250" scrolling="no" frameborder="0" src="http://templates.buscape.com/dynatemplate/abril_300x250.html?type=viajeaqui"></iframe>';

//start quando carregar a pagina.
function vit_Init() {
	if(document.getElementById("vitrine_P")) {
		document.getElementById("vitrine_P").innerHTML=iframe_BP_P;
		//ocapi_ecommerce(ocapi_P);
	}
	if(document.getElementById("vitrine_M")) {
		document.getElementById("vitrine_M").innerHTML=iframe_BP_M;
		//ocapi_ecommerce(ocapi_M);
	}
	if(document.getElementById("vitrine_G")) {
		document.getElementById("vitrine_G").innerHTML=iframe_BP_G;
		//ocapi_ecommerce(ocapi_G);
	}
	
}
vit_Init();